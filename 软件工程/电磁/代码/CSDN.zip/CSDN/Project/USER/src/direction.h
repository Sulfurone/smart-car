#ifndef _DIERCTION_H
#define _DIERCTION_H

#include "headfile.h"

extern float Price_PWM;
void DerectError_Get();
void Direction_Out();
void DifferControl();

#endif